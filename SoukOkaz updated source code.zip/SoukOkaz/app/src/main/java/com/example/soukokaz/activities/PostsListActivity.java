package com.example.soukokaz.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.soukokaz.R;
import com.example.soukokaz.adapters.MySoukOkazAdapter;
import com.example.soukokaz.databinding.ActivityPostsListBinding;
import com.example.soukokaz.models.MyPost;
import com.example.soukokaz.storage.MySQLiteDB;

import java.util.ArrayList;
import java.util.List;

public class PostsListActivity extends AppCompatActivity {
    ActivityPostsListBinding binding;

    private MySoukOkazAdapter mySoukOkazAdapter;
    private List<MyPost> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPostsListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        list = new ArrayList<>();
        publishPostList();

        mySoukOkazAdapter = new MySoukOkazAdapter(list, this);
        binding.rvPostList.setLayoutManager(new LinearLayoutManager(this));
        binding.rvPostList.setAdapter(mySoukOkazAdapter);

        binding.ivPostAdd.setOnClickListener(v -> {
            startActivity(new Intent(PostsListActivity.this, AddEditPostActivity.class));
            finish();
        });

        binding.searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return true;
            }
        });
        binding.tvLogOut.setOnClickListener(v->{
            finish();
        });
    }
    private void filter(String query) {
        ArrayList<MyPost> filteredList = new ArrayList<>();

        String lowerCaseQuery = query.toLowerCase(); // Convert query to lowercase

        for (MyPost post : list) {
            String comment = post.getPost_comment().toLowerCase();
            String userNamePost = post.getUserNamePosted().toLowerCase();
            if (comment.contains(lowerCaseQuery) ||userNamePost.contains(lowerCaseQuery) ) {
                filteredList.add(post);
            }
        }

        // Update RecyclerView with filtered list
        mySoukOkazAdapter = new MySoukOkazAdapter(filteredList, this);
        binding.rvPostList.setAdapter(mySoukOkazAdapter);
        mySoukOkazAdapter.notifyDataSetChanged();
    }

    public void publishPostList() {
        MySQLiteDB mySQLiteDB = new MySQLiteDB(PostsListActivity.this);
        list = mySQLiteDB.getAllPosts();
    }


}