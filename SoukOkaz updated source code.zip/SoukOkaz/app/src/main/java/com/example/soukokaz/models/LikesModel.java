package com.example.soukokaz.models;

public class LikesModel {
    int userId,postId;
    int Id;

    public LikesModel(int userId, int postId, int id) {
        this.userId = userId;
        this.postId = postId;
        Id = id;
    }

    public LikesModel() {
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getPostId() {
        return postId;
    }

    public void setPostId(int postId) {
        this.postId = postId;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }
}
