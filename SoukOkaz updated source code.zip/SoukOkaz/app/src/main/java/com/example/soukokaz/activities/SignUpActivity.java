package com.example.soukokaz.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.example.soukokaz.R;
import com.example.soukokaz.databinding.ActivitySignUpBinding;
import com.example.soukokaz.models.Users;
import com.example.soukokaz.storage.MySQLiteDB;

public class SignUpActivity extends AppCompatActivity {
    ActivitySignUpBinding binding;
    MySQLiteDB mySQLiteDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignUpBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        mySQLiteDB = new MySQLiteDB(SignUpActivity.this);

        binding.btnLogin.setOnClickListener(v -> {
            String name = binding.etdUsername.getText().toString().trim();
            String password = binding.etdPassword.getText().toString().trim();
            String passwordConfirm = binding.etdPasswordConfirm.getText().toString().trim();
            String userNamePosted = binding.etdUserPostName.getText().toString().trim();

            if (binding.etdUserPostName.getText().toString().isEmpty()) {
                binding.etdUserPostName.setError("please fill this fields");
                return;
            }
            if (name.isEmpty()) {
                binding.etdUsername.setError("please fill this fields");
                return;

            } else if (binding.etdAddress.getText().toString().isEmpty()) {
                binding.etdAddress.setError("please fill this fields");
                return;
            } else if (password.isEmpty()) {
                binding.etdPassword.setError("please fill password fields");
                return;

            } else if (passwordConfirm.isEmpty()) {
                binding.etdPasswordConfirm.setError("please fill password fields");
                return;

            } else if (!password.equals(passwordConfirm)) {
                Toast.makeText(this, "password not match", Toast.LENGTH_SHORT).show();
            } else if (binding.etdAddress.getText().toString().isEmpty()) {
                binding.etdAddress.setError("please fill this fields");
            } else {
                Users users = new Users(name, password, userNamePosted);
                boolean result = mySQLiteDB.addUsers(users);
                if (result == true) {
                    Toast.makeText(this, "Add Successfully User", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "Some Thing Wrong ", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}