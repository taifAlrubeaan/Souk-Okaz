package com.example.soukokaz.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.example.soukokaz.R;
import com.example.soukokaz.databinding.ActivityLoginActivtyBinding;
import com.example.soukokaz.models.Users;
import com.example.soukokaz.storage.MySQLiteDB;

import java.util.ArrayList;
import java.util.List;

public class LoginActivty extends AppCompatActivity {

    ActivityLoginActivtyBinding binding;
    List<Users>list;
    MySQLiteDB database;
    public int UserId1=-1;
    public static int UserId=-1;
    public static String USERNAMEPOSTED;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        list = new ArrayList<>();
        binding =ActivityLoginActivtyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        database = new MySQLiteDB(LoginActivty.this);
        binding.tvSignUp.setOnClickListener(v->{
            startActivity(new Intent(LoginActivty.this,SignUpActivity.class));
        });
        binding.btnLogin.setOnClickListener(v->{
            String userName= binding.etdUserEmail.getText().toString().trim();
            String Password = binding.etdPassword.getText().toString().trim();

            if(userName.isEmpty()){
                binding.etdUserEmail.setError("please fill this fields");
            } else if (Password.isEmpty()) {
                binding.etdPassword.setError("please fill this fields");
            }else{
                list = database.getUser();
                for (int  i = 0 ; i < list.size() ; i ++){
                    Users users = list.get(i);
                    if(users.getUserName().equals(userName) || users.getUserName()==userName){
                        if(users.getPassword().equals(Password) || users.getPassword()==Password){
                            UserId= users.getId();
                            UserId1=0;
                            USERNAMEPOSTED= users.getUserNamePosted();
                            startActivity(new Intent(LoginActivty.this,PostsListActivity.class).putExtra("id",users.getId()));
                        }
                    }
                }
                if(UserId1==-1){
                    Toast.makeText(this, "please SignUp", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}