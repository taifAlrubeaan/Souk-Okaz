package com.example.soukokaz.models;

import java.io.Serializable;

public class MyPost implements Serializable {

    public int post_Id;
    int UserId;
    int likeCounts;
    private byte[] post_image;
    private String post_comment;
    private String post_date_time;

    public String getUserNamePosted() {
        return userNamePosted;
    }

    public void setUserNamePosted(String userNamePosted) {
        this.userNamePosted = userNamePosted;
    }

    private String userNamePosted;

    public MyPost() {
    }

    public int getUserId() {
        return UserId;
    }

    public void setUserId(int userId) {
        UserId = userId;
    }

    public int getLikeCounts() {
        return likeCounts;
    }

    public void setLikeCounts(int likeCounts) {
        this.likeCounts = likeCounts;
    }

    public MyPost(String post_comment, String post_date_time, byte[] post_image, int UserId, int likeCounts,String userNamePosted) {
        this.post_image = post_image;
        this.post_comment = post_comment;
        this.post_date_time = post_date_time;
        this.UserId=UserId;
        this.likeCounts=likeCounts;
        this.userNamePosted=userNamePosted;
    }

    public int getPost_Id() {
        return post_Id;
    }

    public void setPost_Id(int post_Id) {
        this.post_Id = post_Id;
    }

    public byte[] getPost_image() {
        return post_image;
    }

    public void setPost_image(byte[] post_image) {
        this.post_image = post_image;
    }

    public String getPost_comment() {
        return post_comment;
    }

    public void setPost_comment(String post_comment) {
        this.post_comment = post_comment;
    }

    public String getPost_date_time() {
        return post_date_time;
    }

    public void setPost_date_time(String post_date_time) {
        this.post_date_time = post_date_time;
    }
}
