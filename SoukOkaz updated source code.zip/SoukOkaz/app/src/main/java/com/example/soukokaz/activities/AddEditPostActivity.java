package com.example.soukokaz.activities;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.soukokaz.R;
import com.example.soukokaz.databinding.ActivityAddEditPostBinding;
import com.example.soukokaz.models.MyPost;
import com.example.soukokaz.storage.MySQLiteDB;
import com.example.soukokaz.utils.DBImageBitmapUtility;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddEditPostActivity extends AppCompatActivity {
    ActivityAddEditPostBinding binding;
    private Uri uri = null;
    MyPost myPost;
    private boolean stateSaveOrUpdate = false;
    private boolean stateImageChanged = false;
    private final int REQUEST_CODE_GALLERY = 45;
    Bitmap bitmap;
    byte[] bytes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddEditPostBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();

        binding.ivGallery.setOnClickListener(v -> {
            Intent img_intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            img_intent.setType("image/*");
            startActivityForResult(img_intent, 45);
        });

        binding.btnPostSave.setOnClickListener(v -> {
            savePost();
        });

        binding.ivClose.setOnClickListener(v -> {
            startActivity(new Intent(getApplicationContext(), PostsListActivity.class));
        });

        binding.ivBack.setOnClickListener(v -> {
            startActivity(new Intent(getApplicationContext(), PostsListActivity.class));
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_GALLERY && resultCode == RESULT_OK && data != null) {
            uri = data.getData();
            try {
                InputStream inputStream=getContentResolver().openInputStream(uri);
                bitmap= BitmapFactory.decodeStream(inputStream);
                bitmap = Bitmap.createScaledBitmap(bitmap, 400, 400, false);
                binding.ivPostImage.setImageBitmap(bitmap);
                stateImageChanged =true;

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void savePost() {
        if (binding.ivPostImage.getDrawable() == null && uri == null) {
            Toast.makeText(this, "Please choose Image", Toast.LENGTH_SHORT).show();
        } else if (binding.etPostComment.getText().toString().isEmpty()) {
            Toast.makeText(this, "Please enter post description", Toast.LENGTH_SHORT).show();
        } else {
            String postComment = binding.etPostComment.getText().toString().trim();
            if (stateSaveOrUpdate==true) {
                myPost.setPost_comment(postComment);
            }
            if (uri != null) {
                if (stateImageChanged && stateSaveOrUpdate) {
                    myPost.setPost_image(DBImageBitmapUtility.getBytes(bitmap));
                    updateMyPostObj();
                } else {
                    String currentDateTime = getCurrentDateTime();
                    MyPost myPost = new MyPost(postComment, currentDateTime,  DBImageBitmapUtility.getBytes(bitmap), LoginActivty.UserId, 0,LoginActivty.USERNAMEPOSTED);
                    addPostObj(myPost);
                }
            } else {
                updateMyPostObj();
            }
        }
    }

    public void addPostObj(MyPost myPost) {
        try {
            MySQLiteDB mySQLiteDB = new MySQLiteDB(this);
            boolean is_inserted = mySQLiteDB.addPost(myPost);

            if (is_inserted) {
                clearView();
                Toast.makeText(getApplicationContext(), "Post saved successfully ", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), PostsListActivity.class));
                finish();
            } else {
                Toast.makeText(getApplicationContext(), "Error Occurred ", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Exception: " + e, Toast.LENGTH_SHORT).show();
        }

    }

    public void updateMyPostObj() {
        MySQLiteDB mySQLiteDB = new MySQLiteDB(this);
        boolean is_updated = mySQLiteDB.updatePost(myPost);

        if (is_updated) {
            clearView();
            Toast.makeText(getApplicationContext(), "Post updated successfully ", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getApplicationContext(), PostsListActivity.class));
            finish();
        } else {
            Toast.makeText(getApplicationContext(), "Error Occurred ", Toast.LENGTH_SHORT).show();
        }
    }

    private String getCurrentDateTime() {
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy hh:mm", Locale.getDefault());
        String formattedDate = df.format(c);
        return formattedDate;
    }

    private void init() {


        MyPost myPostEditData = (MyPost) getIntent().getSerializableExtra("data");

        if (myPostEditData != null) {
            binding.ivPostImage.setImageBitmap(DBImageBitmapUtility.getImage(myPostEditData.getPost_image()));
            binding.etPostComment.setText(myPostEditData.getPost_comment());
            stateSaveOrUpdate = true;
            myPost=myPostEditData;
        }
    }


    public void clearView() {
        binding.ivPostImage.setImageResource(R.drawable.avatar);
        binding.etPostComment.setText("");
        uri = null;
        stateImageChanged = false;
        stateSaveOrUpdate = false;
    }
}