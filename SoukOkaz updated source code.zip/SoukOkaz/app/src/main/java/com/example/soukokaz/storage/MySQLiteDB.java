package com.example.soukokaz.storage;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.soukokaz.activities.LoginActivty;
import com.example.soukokaz.models.LikesModel;
import com.example.soukokaz.models.MyPost;
import com.example.soukokaz.models.Users;

import java.util.ArrayList;
import java.util.List;

public class MySQLiteDB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MySoukOkazDataBase9";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "MySoukOkazTable";
    Context context;
    List<MyPost> list;

    public MySQLiteDB(@Nullable Context context) {

        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
        list = new ArrayList<>();

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_QUERY = "CREATE TABLE " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, Comment VARCHAR, DateTime VARCHAR, Image BLOB,UserId INTEGER ,likesCounts INTEGER,userNamePosted Text )";
        db.execSQL(CREATE_TABLE_QUERY);
        db.execSQL("create table LoginUser(KeyId INTEGER primary key,UserName Text,Password Text,userNamePosted Text)");
        db.execSQL("create table LikesTable(KeyId INTEGER primary key,UserID INTEGER,PostId INTEGER)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
        db.execSQL("Drop table if exists LoginUser");
        db.execSQL("Drop table if exists LikesTable");

    }

    public boolean addUsers(Users users) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put("userName", users.getUserName());
        contentValues.put("Password", users.getPassword());
        contentValues.put("userNamePosted", users.getUserNamePosted());

        long Result = db.insert("LoginUser", null, contentValues);
        if (Result == -1) {
            return false;
        } else {
            return true;
        }

    }
    public boolean addLikesPost(int userId,int postId){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("UserID", userId);
        values.put("PostId", postId);
        long Result = db.insert("LikesTable", null, values);
        if (Result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean addPost(MyPost myPost) {

        ContentValues values = new ContentValues();

        if (myPost.getPost_image() != null) {
            values.put("comment", myPost.getPost_comment());
            values.put("datetime", myPost.getPost_date_time());
            values.put("image", myPost.getPost_image());
            values.put("UserId", myPost.getUserId());
            values.put("likesCounts", myPost.getLikeCounts());
            values.put("userNamePosted", myPost.getUserNamePosted());

            SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
            Long l = sqLiteDatabase.insert(TABLE_NAME, "", values);

            if (l > 0) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }


    }

    public List<MyPost> getAllPosts() {

        List<MyPost> list = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        String RETRIEVE_RECORD_QUERY = "SELECT * FROM " + TABLE_NAME;
        Cursor cursor = sqLiteDatabase.rawQuery(RETRIEVE_RECORD_QUERY, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                MyPost myPost = new MyPost();
                myPost.setPost_Id(Integer.parseInt(cursor.getString(0)));
                myPost.setPost_comment(cursor.getString(1));
                myPost.setPost_date_time(cursor.getString(2));
                myPost.setPost_image(cursor.getBlob(3));
                myPost.setUserId(cursor.getInt(4));
                myPost.setLikeCounts(cursor.getInt(5));
                myPost.setUserNamePosted(cursor.getString(6));
                list.add(myPost);

            } while (cursor.moveToNext());
        }
        if (cursor != null) {
            cursor.close();
        }

        return list;
    }

    public boolean updatePost(MyPost myPost) {

        ContentValues values = new ContentValues();
        values.put("comment", myPost.getPost_comment());
        values.put("datetime", myPost.getPost_date_time());
        values.put("image", myPost.getPost_image());
        values.put("UserId", myPost.getUserId());
        values.put("likesCounts", myPost.getLikeCounts());

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        int result = sqLiteDatabase.update(TABLE_NAME, values, "ID=?", new String[]{myPost.getPost_Id() + ""});

        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean deletePost(String item_ID) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        int result = sqLiteDatabase.delete(TABLE_NAME, "ID=?", new String[]{item_ID});


        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }
    public boolean disLikePost(int userId, int postId) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        String whereClause = "UserId=? AND PostId=?";
        String[] whereArgs = new String[]{String.valueOf(userId), String.valueOf(postId)};
        int result = sqLiteDatabase.delete("LikesTable", whereClause, whereArgs);

        return result > 0;
    }

    public List<Users> getUser() {
        List<Users> dataList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + "LoginUser";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Users dataModel = new Users();
                dataModel.setId(cursor.getInt(0));
                dataModel.setUserName(cursor.getString(1));
                dataModel.setPassword(cursor.getString(2));
                dataModel.setUserNamePosted(cursor.getString(3));
                dataList.add(dataModel);

            } while (cursor.moveToNext());
        }
        return dataList;
    }
    public List<LikesModel> getLikes() {
        List<LikesModel> dataList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + "LikesTable";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                LikesModel dataModel = new LikesModel();
                dataModel.setId(cursor.getInt(0));
                dataModel.setUserId(cursor.getInt(1));
                dataModel.setPostId(cursor.getInt(2));
                dataList.add(dataModel);

            } while (cursor.moveToNext());
        }
        return dataList;
    }
}
