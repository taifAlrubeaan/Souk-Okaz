package com.example.soukokaz.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.soukokaz.R;
import com.example.soukokaz.activities.AddEditPostActivity;
import com.example.soukokaz.activities.LoginActivty;
import com.example.soukokaz.activities.PostsListActivity;
import com.example.soukokaz.models.LikesModel;
import com.example.soukokaz.models.MyPost;
import com.example.soukokaz.storage.MySQLiteDB;
import com.example.soukokaz.utils.DBImageBitmapUtility;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class MySoukOkazAdapter extends RecyclerView.Adapter<MySoukOkazAdapter.MyViewHolder> {

    List<MyPost> list;
    private Context context;
    private LayoutInflater inflater;
    private int total_titles;
    MySQLiteDB database;
    List<LikesModel>likesModels;
    int checkLikes=0;

    public MySoukOkazAdapter(List<MyPost> list, Context context) {
        this.list = list;
        this.context = context;
        this.inflater = LayoutInflater.from(this.context);
        total_titles = 0;
        database = new MySQLiteDB(context);
        likesModels = new ArrayList<>();
    }

    @NonNull
    @Override
    public MySoukOkazAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.row_view_posts_list, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MySoukOkazAdapter.MyViewHolder holder, int position) {
        MyPost myPost = list.get(position);

        holder.post_image.setImageBitmap(DBImageBitmapUtility.getImage(myPost.getPost_image()));
        holder.post_comment.setText(myPost.getPost_comment());
        holder.post_date_time.setText(myPost.getPost_date_time());
        holder.tvLike.setText(""+myPost.getLikeCounts());
        holder.tvPostName.setText(myPost.getUserNamePosted());
        likesModels = database.getLikes();

        for (LikesModel likesModel : likesModels) {
            if (likesModel.getUserId() == LoginActivty.UserId && likesModel.getPostId() == myPost.getPost_Id()) {
                holder.imvLike.setColorFilter(context.getResources().getColor(R.color.red));
                break;
            }
        }

        holder.post_edit.setOnClickListener(v -> {
            context.startActivity(new Intent(context,AddEditPostActivity.class).putExtra("data",myPost));
        });
        holder.post_delete.setOnClickListener(v -> {
            deletePost(myPost, holder.getAdapterPosition(), v);
        });
        holder.imvLike.setOnClickListener(v -> {
            likesModels = database.getLikes();
            boolean userLiked = false;

            for (LikesModel likesModel : likesModels) {
                if (likesModel.getUserId() == LoginActivty.UserId && likesModel.getPostId() == myPost.getPost_Id()) {
                    userLiked = true;
                    break;
                }
            }

            if (userLiked) {
                holder.imvLike.setColorFilter(context.getResources().getColor(R.color.black));
                myPost.setLikeCounts(myPost.getLikeCounts() - 1);
                holder.tvLike.setText("" + myPost.getLikeCounts());
                database.disLikePost(LoginActivty.UserId, myPost.getPost_Id());
            } else {
                holder.imvLike.setColorFilter(context.getResources().getColor(R.color.red));
                myPost.setLikeCounts(myPost.getLikeCounts() + 1);
                holder.tvLike.setText("" + myPost.getLikeCounts());
                database.addLikesPost(LoginActivty.UserId, myPost.getPost_Id());
            }

            boolean result = database.updatePost(myPost);
        });




    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        private ImageView post_image, post_edit, post_delete,imvLike;
        private TextView post_comment,post_date_time,tvLike,tvPostName;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            post_image = itemView.findViewById(R.id.iv_post_image);
            post_edit = itemView.findViewById(R.id.iv_post_edit);
            post_delete = itemView.findViewById(R.id.iv_post_delete);
            post_comment = itemView.findViewById(R.id.tv_post_comment);
            post_date_time = itemView.findViewById(R.id.tv_post_date_time);
            imvLike = itemView.findViewById(R.id.ivLike);
            tvLike = itemView.findViewById(R.id.tvLike);
            tvPostName = itemView.findViewById(R.id.tvPostName);
        }
    }

    private void deletePost(MyPost myPost, int index, View view) {

        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(view.getRootView().getContext())
                .setIcon(android.R.drawable.ic_delete)
                .setTitle("Alert")
                .setMessage("Do you want to delete this Post")
                .setCancelable(false)
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                })
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        try {
                            MySQLiteDB mySQLiteDB=new MySQLiteDB(context.getApplicationContext());
                            boolean is_deleted=mySQLiteDB.deletePost(myPost.getPost_Id()+"");

                            if (is_deleted)
                            {
                                Toast.makeText(context.getApplicationContext(), "Post deleted successfully ", Toast.LENGTH_SHORT).show();
//                                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                                list.remove(index);
                                notifyItemRemoved(index);
                            }
                            else
                            {
                                Toast.makeText(context.getApplicationContext(), "Error Occurred ", Toast.LENGTH_SHORT).show();
                            }
                        }
                        catch (Exception e)
                        {
                            Toast.makeText(context.getApplicationContext(), "Exception: "+e, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
        alertDialog.show();
    }

    public static Bitmap getImage(byte[] image) {
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }

}
