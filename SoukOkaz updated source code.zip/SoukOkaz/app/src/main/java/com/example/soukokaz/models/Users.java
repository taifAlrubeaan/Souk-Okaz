package com.example.soukokaz.models;

public class Users {
    String UserName;
    String Password;

    public String getUserNamePosted() {
        return userNamePosted;
    }

    public void setUserNamePosted(String userNamePosted) {
        this.userNamePosted = userNamePosted;
    }

    String userNamePosted;
    int Id;

    public Users() {
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public Users(String userName, String password,String userNamePosted) {
        UserName = userName;
        Password = password;
        this.userNamePosted=userNamePosted;
    }
}
